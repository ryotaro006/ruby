puts "webcamp".swapcase
