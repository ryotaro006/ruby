puts "WEBCAMP".reverse
