puts 100
puts 100 + 3
puts 100 - 3
puts 100 * 3
puts 100 / 3
puts 100 % 3
