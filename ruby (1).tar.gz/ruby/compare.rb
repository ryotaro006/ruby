total = 100
if total < 200
  puts "合計は２００未満です"
 end
 
 if total >=150
   puts "合計は１５０以上です"
 end
 