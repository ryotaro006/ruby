webcamp = "プログラミング学習"
puts webcamp

webcamp = "オンラインプログラミング学習"
puts webcamp