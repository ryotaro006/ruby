Pi = 3.14
puts Pi

Pi = 100
puts Pi
