puts "WEBCAMPでプログラミング学習".methods
