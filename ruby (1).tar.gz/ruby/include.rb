puts "WEBCAMPでプログラミング学習".include?("WEBCAMP")
